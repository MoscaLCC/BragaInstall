
/**
 * Escreva a descrição da classe Main aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
import java.util.*;
import static java.lang.System.*;
public class Main
{
    public static void main(String [] args){
        out.print('\u000C');
        GestHiper gest= new GestHiper();
        Scanner lerI = new Scanner(System.in);
        Scanner lerS = new Scanner(System.in);
        int cont=0;
        String cdp2="";
        out.println("BEM VINDO AO GESTHIPER-OO,\n");
    do{out.println("-------------------------------------------------------------------------");
       out.println("0) Carregar estruturas");
       out.println("1)Lista ordenada com os códigos dos produtos nunca comprados e respectivo total");
       out.println("2)Lista ordenada com os códigos dos clientes que nunca compraram e seu total");
       out.println("3)Dado um mês válido, determinar o número total de compras e o total de cliente distintos que as realizaram");
       out.println("4) Dado um código de cliente, determinar, para cada mês, quantas compras fez,quantos produtos distintos comprou e quanto gastou. Apresentar também o total anual facturado ao cliente;");
       out.println("5) Dado o código de um produto existente, determinar, mês a mês, quantas vezes foi comprado, por quantos clientes diferentes e o total facturado;");
       out.println("6)Dado o código de um produto existente, determinar, mês a mês, quantas vezes foicomprado em modo N e em modo P e respectivas facturações;");
       out.println("7) Dado o código de um cliente determinar a lista de códigos de produtos que mais comprou (e quantos), ordenada por ordem decrescente de quantidade e, para quantidades iguais, por ordem alfabética dos códigos;");
       out.println("8) Determinar o conjunto dos X produtos mais vendidos em todo o ano (em número de unidades vendidas) indicando o número total de distintos clientes que o compraram");
       out.println("9)Determinar os X clientes que compraram um maior número de diferentes produtos, indicando quantos, sendo o critério de ordenação igual a 7;");
       out.println("10) Dado o código de um produto, determinar o conjunto dos X clientes que mais o compraram e qual o valor gasto (ordenação cf. 7);");
       
       out.println("15)Sair do Programa");
       
       cont=lerI.nextInt();
       
       switch(cont){
       
          case (0):
          out.println(" A Carregar...."); 
          gest.CarregaDados();
           break;
         
          case (1):
            for(String x: gest.getNaoComprados())
                 out.println(x);
             out.println(" NºTotal:"+gest.getNaoComprados().size());  
              break;
          case (2):    
            for(String x: gest.getNaoCompraram())
                 out.println(x);
             out.println(" NºTotal:"+gest.getNaoCompraram().size());
            break;   
            case (3):
                int m;    
                out.println("Insira um mês");
                m=lerI.nextInt();
                out.println("Nº total de compras:" + gest.QtdClientesCompraramMes(m));
                out.println("Total de clientes diferentes:"+gest.getNumeroComprasMes(m));
                break;
            
            case (4): 
              double tot=0;
              String cd="";
              out.println("Insira o codigo de  cliente");
              cd=lerS.next();
              TRIOcompfatuprod tr;
               for(int i=1;i<13;i++){
                out.println("..........Mes " + i+"..........");
                tr = gest.getInfoMesCliente(cd,i);
                out.println("Nº total de compras:" + tr.getNcomp());
                out.println("Total de produtos distintos:"+tr.getNprods());
                out.println("Faturação mensal:" + tr.getFat());
                tot+= tr.getFat();
            }
                    
                out.println("Faturação Anual" +tot);
               
                break;
            case (5):
               
                String cdp1="";
                out.println("Insira o codigo de  produto");
                cdp1=lerS.next();
                TRIOcompfatuprod tr2;
               for(int i=1;i<13;i++){
                out.println("\n..........Mes " + i+"..........");
                tr2 = gest.getInfoMesProduto(cdp1,i);
                out.println("Nº total de compras:" + tr2.getNcomp());
                out.println("Total de clientes distintos:"+tr2.getNprods());
                out.println("Faturação mensal:" + tr2.getFat());
               
            }
           
            break;
            case (6):
            
              cdp2="";
                out.println("Insira o codigo de  produto");
                cdp2=lerS.next();
               Contabilidade x;
               for(int i=1;i<13;i++){
                out.println("\n..........Mes " + i+"..........");
                x = gest.getContabilidadeMensal(cdp2,i);
                // Por em toString da Contabilidade?????? 
                out.println("Nº de Compras em modo N:" + x.getNcomp());
                out.println("Faturação em modo N:" + x.getFatuN());
                out.println("Nº de Compras em modo P:"+x.getPcomp());
                out.println("Faturação em modo P:" + x.getFatuP());
               
            
            }
            
            
            break;
           case (7):
              out.println("Insira o codigo de  cliente");
              cdp2=lerS.next();  
              int i=0;
              for(ParCodInt pr: gest.ProdutosMaisCompradosCliente(cdp2)){
                out.println(pr);
                i++;
                }
             out.println(" Nº de Produtos diferentes comprados:"+ i);
             break;
             
            case(8):
               out.println("Insira o nº de elementos que quer ver ");
               int tt=lerI.nextInt();
                    
              for(TrioCodIntInt c: gest.getProdutosMaisVendidos()){
                     if(tt<=0)break; 
                     out.println(c);
                      tt--;
                    }    
            
            
                break;
            case(9): 
               out.println("Insira o nº de elementos que quer ver ");
               int t1=lerI.nextInt();
                    
              for(ParCodStrings c: gest.getOsMaioresCompradoress()){
                     if(t1<=0)break; 
                     out.println(c);
                      t1--;
                    }    
              break;
             default: break;
        
    }
    }while(cont!=15);
    
     out.println("------------ADEUS---------------");
}






}
