
/**
 * Write a description of class GestHiper here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.*;

public class GestHiper implements Serializable
{
   //catalogo de produtos
   private CatalogoProdutos produtos;
   //catologo de clientes
   private CatalogoClientes clientes;
   // contabilidade
   private Contabilidade_Super contab;
   //estrutura de compras
   private CatalogoCompras cat; 
   
   
   public GestHiper(){
    this.produtos = new CatalogoProdutos ();
    this.clientes = new CatalogoClientes();
    this.contab= new Contabilidade_Super();
    this.cat = new CatalogoCompras ();
}
   
 // public GestHiper(GestHiper x){}

 
public TreeSet<String> getProdutos (){
TreeSet<String> x = new TreeSet<String>();
for(String y: this.produtos.getProdutos())
    x.add(y);

return x;
}
 
 
 
 
 
 
 
 
    public boolean foiComprado(String cod)
{ 
    return this.cat.foiComprad(cod);
  }

 
 public boolean ClienteComprou(String cod){
    return this.cat.Comprou(cod);
    
    } 
  
 
 public TreeSet<String> getNaoCompraram(){
    TreeSet<String> x = new TreeSet<String>();
for(String y: this.clientes.getClientes())
    if(!ClienteComprou(y)){System.out.println("nao comprou");
        x.add(y);}
    
    return x;
    }
 
 
 
 
 
 public TreeSet<String> getNaoComprados(){
    TreeSet<String> x = new TreeSet<String>();
for(String y: this.produtos.getProdutos())
    if(!foiComprado(y))
        x.add(y);
    
    return x;
    }
 
 
 
 
 public int getNumeroComprasproduto(){
    return this.cat.getNumeroComprasprod();
}
 

public int QtdClientesCompraramMes(int mes){
return this.cat.QtdClientesCompraram(mes);}




public int getNumeroComprasMes(int mes){
   
     return this.cat.getNumeroCompras(mes);
}
 

    
    
     public boolean existeCliente(String cod){
    return this.clientes.existeCli(cod);}
    
  
    
    public void add1Contabilidade(Contabilidade x){
    this.contab.addContabilidade(x);
}

public void addCompraproduto(Compra x){
       this.cat.addCompraprod(x);
}
 

public Contabilidade getContabilidadeMensal (String prod, int mes){

    return this.contab.getContabilidadeMes(prod,mes);


}




public boolean existeproduto(String x){
    if (this.produtos.existeProd(x)) return true;
    else return false;
}







public TRIOcompfatuprod getInfoMesCliente(String cd, int m){
return this.cat.getInfoMesCli(cd,m);
     
}


public TRIOcompfatuprod getInfoMesProduto(String cd, int m){
return this.cat.getInfoMesProd(cd,m);
     }

public TreeSet<TrioCodIntInt> getProdutosMaisVendidos(){
   TreeSet<TrioCodIntInt> x= new TreeSet<TrioCodIntInt> (new ComparatorTrioCodIntInt());
    
    for (TrioCodIntInt t:this.cat.getMaisVendidos().values())
      x.add(t);

     return x; 
}

  
public TreeSet<ParCodStrings> getOsMaioresCompradoress(){
   TreeSet<ParCodStrings> x= new TreeSet<ParCodStrings> (new ComparatorParCodStrings());
    
    for (ParCodStrings t:this.cat.getMaioresCompradores().values())
      x.add(t);

     return x; 
}
   
     
public void addCompracliente(Compra x){
       this.cat.addCompracli(x);
        
}

 public void addCompraInval(Compra x){
    this.cat.addCompraInvalida(x);
    }

    public void addCompra(Compra x){
    this.addCompraproduto(x);
    this.addCompracliente(x);

}

////////////////

public TreeSet<ParCodInt> ProdutosMaisCompradosCliente(String x){
return this.cat.getMaisComprou(x);
}








//////////////////


public boolean compraValida(Compra x){
if(x.getCodcli().length()==5 && x.getCodprod().length()==6 && x.getPreco()>=0 && (x.getModo()=='N'|| x.getModo()=='P')&& (x.getMes()>0 &&x.getMes()<13))
    return (this.existeproduto(x.getCodprod())&& this.existeCliente(x.getCodcli()));

else return false;

}

   public int leCatalogoProdutos () throws IOException{
    int i=0;
    try {
       this.produtos.leProdutos();
               }
        catch(IOException e){System.out.println(e.getMessage());}
    
    return i;
    }

    public int leCatologoClientes () throws IOException{
    int i=0;
    try {
        i=this.clientes.leClientes();
               }
        catch(IOException e){System.out.println(e.getMessage());}
    
    return i;
    }

    /*Carrega todas as estruturas*/

public int CarregaDados(){
    Compra cop;int i=0;
    try{ 
    int c= this.clientes.leClientes ();
    int pr= this.produtos.leProdutos ();
     

    String linha= "";String txt="";
        StringTokenizer st ;
        String codprod; String codcli; int qt, mes;
        char p;
        double preco;
        
        BufferedReader bin = new BufferedReader (new FileReader( "Compras.txt"));
                while (bin.ready()){
                linha = bin.readLine();
                st = new StringTokenizer(linha," ");
                codprod = st.nextToken();
                //preco= Integer.valueOf(st.nextToken()).floatValue();
                //txt= st.nextToken();
                //preco = Integer.parseInt(txt);
                preco=Float.valueOf(st.nextToken()).floatValue();
                qt = Integer.valueOf(st.nextToken()).intValue();
                p = st.nextToken().charAt(0);
                codcli = st.nextToken();
                mes=Integer.valueOf(st.nextToken()).intValue();
                //int m, String c, String p, char mo,float pr, int u
                cop=  new Compra(mes,codcli,codprod,p,preco,qt);
                //Contabilidade x= new Contabilidade();
                if(compraValida(cop)){
                this.addCompra(cop.clone());
                //Contabilidade(String c,int nc, int pc,double n, double p, int me)
                if(p=='N'){
                Contabilidade x= new Contabilidade(codprod,qt,0,preco,0,mes);
                this.add1Contabilidade(x.clone());
                x=null;
            }
                else{ Contabilidade y= new Contabilidade(codprod,0,qt,0,preco,mes);
                this.add1Contabilidade(y.clone());
               y=null;
            }}
                
            else {this.addCompraInval(cop.clone());
            
            }
            cop=null;
                 i++;
            }
               bin.close();
               }
        catch(IOException e){System.out.println(e.getMessage());}
    return i;
    }

}
    
    
    

